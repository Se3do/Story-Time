<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>
  <link rel="stylesheet" href="/Css/final-log.css" />
</head>

<body>
  <div class="container">
    <form id="form" action="/php/lo.php" method="POST">
      <a href="html/index.html"><img src="css/imgs/txtb.png" alt="Avatar" class="avatar" /></a>
      <h1>Login now</h1>

      <div class="input-field">
        <label for="username">Email</label>
        <input type="text" id="username" name="username" placeholder="Enter your email" />
      </div>
      <div class="input-field">
        <label for="password">Password</label>
        <input type="password" id="password" name="password" placeholder="Enter your password" />
      </div>
      <div class="checkbox">
        <input type="checkbox" id="remember-me" name="remember-me" />
        <label for="remember-me">Remember me</label> <br />
        <br />
      </div>
      <button type="submit">Login</button> <br />

      <a href="#">Don't have an account? Register now!</a>
      <br><br>
      <a href="#">Forgot your password?</a>
      <div class="social-login">
        <p>- Login with -</p>
        <a href="#"><img class="login-icons" src="/Story-time/images/face-png.jpg" alt="Facebook" /></a>
        <a href="#"><img class="login-icons" src="/Story-time/images/google-logo.png" alt="Twitter" /></a>
      </div>
    </form>
  </div>
</body>

</html>