<?php
echo "login successful";
// Define database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "story-time";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection success
if ($conn->connect_error) {
    die("Failed to connect to database: " . $conn->connect_error);
}

// Receive login data from the form
$email = $_POST['username'];
$password = $_POST['password'];

// SQL query to verify login credentials
$sql = "SELECT * FROM customers WHERE User_Email='$email' AND User_Password='$password'";
$result = $conn->query($sql);

// Check if there is a result
if ($result->num_rows > 0) {
    // Login credentials are correct
    echo "Login successful!";
} else {
    // Login credentials are incorrect
    echo "Incorrect username or password!";
}

// Close the database connection
$conn->close();
