<?php
echo "done";

// Define database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "story-time";

// Create connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection success
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Receive form data
$username = $_POST['username'];
$email = $_POST['User_Email'];
$phone = $_POST['User_phone'];
$password = password_hash($_POST['User_Password'], PASSWORD_DEFAULT); // Hash password

// Prepare SQL query to insert data into the database
$sql = "INSERT INTO customers (Username, User_Email, User_phone, User_Password) VALUES ('$username', '$email', '$phone', '$password')";

// Execute the SQL query
if ($conn->query($sql) === TRUE) {
    echo "User registered successfully!";
} else {
    echo "Error occurred while registering user: " . $conn->error;
}

// Close database connection
$conn->close();
